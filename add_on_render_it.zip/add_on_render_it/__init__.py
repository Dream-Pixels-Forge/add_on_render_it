bl_info = {
    "name": "Render It",
    "author": "Dimona Patrick",
    "version": (1, 0, 2),
    "blender": (4, 2, 0),
    "location": "Properties > Render It",
    "description": "Enhanced rendering tools with batch camera support",
    "category": "Render",
}

import bpy
import os
import json
import time
from datetime import datetime
from bpy.props import (StringProperty, BoolProperty, IntProperty, 
                      CollectionProperty, EnumProperty, PointerProperty)
from bpy.types import PropertyGroup, AddonPreferences, Scene, Operator, Panel

from typing import Any

 
def ensure_absolute_path(path):
    """Convert relative path to absolute if necessary"""
    if path.startswith("//"):
        return bpy.path.abspath(path)
    return path


# Constants
RESOLUTION_SCALES = [25, 50, 75, 100, 150, 200]
SAMPLE_PRESETS = {
    "Preview": 128,
    "Low": 256,
    "Medium": 512,
    "High": 1024,
    "Ultra": 2048,
    "Maximum": 4096
}

class RenderItPreferences(AddonPreferences):
    bl_idname = __name__

    project_name: StringProperty(
        name="Project Name",
        description="Name of the project for organizing renders",
        default="B3D_Project"
    )

    # Resolution Settings
    default_resolution_x: IntProperty(
        name="Default Width",
        description="Default render width",
        default=1920,
        min=1
    )

    default_resolution_y: IntProperty(
        name="Default Height",
        description="Default render height",
        default=1080,
        min=1
    )

    # Output settings
    default_output_path: StringProperty(
        name="Default Output Path",
        description="Default path for saving renders",
        default="//renders/",
        subtype='DIR_PATH',
        update=lambda self, context: self.ensure_valid_path()
    )

    save_on_render: BoolProperty(
        name="Auto Save Renders",
        description="Automatically save renders when completed",
        default=True
    )

    show_render_time: BoolProperty(
        name="Show Render Time",
        description="Display render completion time",
        default=True
    )

    use_subfolders: BoolProperty(
        name="Use Date Subfolders",
        description="Create date-based subfolders for renders",
        default=True
    )

    def ensure_valid_path(self):
        """Ensure the output path is valid"""
        if not self.default_output_path:
            self.default_output_path = "//renders/"
        elif not self.default_output_path.endswith(os.sep):
            self.default_output_path += os.sep

    def draw(self, context):
        layout = self.layout
        
        # Project Settings
        box = layout.box()
        box.label(text="Project Settings", icon='FILE_BLEND')
        box.prop(self, "project_name")
        
        # Resolution Settings
        box = layout.box()
        box.label(text="Default Resolution", icon='CAMERA_DATA')
        col = box.column()
        
        # Modern split layout for resolution
        split = col.split(factor=0.5)
        subcol = split.column()
        subcol.label(text="Width:")
        subcol.label(text="Height:")
        
        subcol = split.column()
        subcol.prop(self, "default_resolution_x", text="")
        subcol.prop(self, "default_resolution_y", text="")

         # Output Settings
        box = layout.box()
        box.label(text="Output Settings", icon='FILE_FOLDER')
        
        # Show absolute path for reference
        abs_path = bpy.path.abspath(self.default_output_path)
        box.label(text=f"Absolute path: {abs_path}", icon='INFO')
        
        # Output path with folder browser
        row = box.row(align=True)
        row.prop(self, "default_output_path", text="")
        row.operator("render.open_folder", text="", icon='FILE_FOLDER')
        
        # Settings grid
        grid = box.grid_flow(row_major=True, columns=2, align=True)
        grid.prop(self, "save_on_render")
        grid.prop(self, "show_render_time")
        grid.prop(self, "use_subfolders")

class CameraRenderSettings(PropertyGroup):
    camera: PointerProperty(
        name="Camera",
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'CAMERA'
    )
    
    enabled: BoolProperty(
        name="Enabled",
        default=True
    )
    
    use_scene_frames: BoolProperty(
        name="Use Scene Frame Range",
        default=True
    )
    
    frame_start: IntProperty(
        name="Start Frame",
        default=1,
        min=1
    )
    
    frame_end: IntProperty(
        name="End Frame",
        default=250,
        min=1
    )
    
    use_custom_folder: BoolProperty(
        name="Custom Output Folder",
        default=False
    )
    
    output_folder: StringProperty(
        name="Output Folder",
        subtype='DIR_PATH'
    )
    
    create_subfolder: BoolProperty(
        name="Create Camera Subfolder",
        default=True
    )
    
    subfolder_name: StringProperty(
        name="Subfolder Name",
        description="Custom name for camera subfolder (leave empty to use camera name)"
    )
    
    register_render: BoolProperty(
        name="Register Render Result",
        description="Keep render result in Blender's memory",
        default=False
    )

class PresetSettings(PropertyGroup):
    name: StringProperty(name="Name")
    is_selected: BoolProperty(name="Selected", default=False)
    resolution_x: IntProperty(name="Width")
    resolution_y: IntProperty(name="Height")
    resolution_percentage: IntProperty(name="Scale")
    engine: StringProperty(name="Engine")
    cycles_samples: IntProperty(name="Samples")

# Utility Functions
def get_prefs(context: bpy.types.Context) -> RenderItPreferences:
    """Get addon preferences"""
    addon_name = __name__ 
    try:
        return context.preferences.addons[addon_name].preferences
    except KeyError:
        return None

def ensure_dir_exists(path: str) -> None:
    """Create directory if it doesn't exist"""
    try:
        if not os.path.exists(path):
            os.makedirs(path)
    except PermissionError:
        print(f"Permission denied creating directory: {path}")
    except Exception as e:
        print(f"Error creating directory: {path} - {str(e)}")

def format_time(seconds: float) -> str:
    """Format time in seconds to human readable string"""
    minutes, seconds = divmod(int(seconds), 60)
    hours, minutes = divmod(minutes, 60)
    
    if hours > 0:
        return f"{hours}h {minutes}m {seconds}s"
    elif minutes > 0:
        return f"{minutes}m {seconds}s"
    else:
        return f"{seconds}s"

def save_render_state(scene):
    return {
        'original_path': scene.render.filepath,
        'original_format': scene.render.image_settings.file_format,
        'original_use_file_extension': scene.render.use_file_extension,
        'original_use_placeholder': scene.render.use_placeholder,
        'original_use_overwrite': scene.render.use_overwrite
    }

def restore_render_state(scene, state):
    scene.render.filepath = state['original_path']
    scene.render.image_settings.file_format = state['original_format']
    scene.render.use_file_extension = state['original_use_file_extension']
    scene.render.use_placeholder = state['original_use_placeholder']
    scene.render.use_overwrite = state['original_use_overwrite']

def safe_create_directory(path):
    """Safely create a directory without interfering with other processes"""
    try:
        if not os.path.exists(path):
            os.makedirs(path)
        return True
    except PermissionError:
        return False
    except FileExistsError:
        return True
    except Exception:
        return False

def get_unique_filename(base_path, name, extension):
    """Generate a unique filename to avoid conflicts"""
    counter = 1
    filename = f"{name}_{counter:04d}{extension}"
    while os.path.exists(os.path.join(base_path, filename)):
        counter += 1
        filename = f"{name}_{counter:04d}{extension}"
    return filename

def get_project_output_path(context, subfolder=None):
    prefs = get_prefs(context)
    
    if not prefs.project_name:
        return bpy.path.abspath(prefs.default_output_path)
        
    path_parts = [
        bpy.path.abspath(prefs.default_output_path),
        prefs.project_name
    ]
    
    if subfolder:
        path_parts.append(subfolder)
        
    path = os.path.join(*path_parts)
    os.makedirs(path, exist_ok=True)
    return path

class RENDER_PT_zone(bpy.types.Panel):
    """Main panel for Render It addon"""
    bl_label = "Render It"
    bl_idname = "RENDER_PT_zone"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "render"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        render = scene.render
        prefs = get_prefs(context)
        
        if prefs is None:
            layout.label(text="Please check addon preferences", icon='ERROR')
            return

        try:
            # Render Actions
            self.draw_render_actions(layout)
            
            # Resolution Settings
            self.draw_resolution_settings(layout, render, prefs)
            
            # Frame Range
            self.draw_frame_range(layout, scene)
            
            # Sampling Settings
            self.draw_sampling_settings(layout, context)
            
            # Output Settings with modern UI
            self.draw_output_settings(layout, prefs)
            
            # Add this line to show presets
            box = layout.box()
            box.label(text="Presets", icon='PRESET')
            row = box.row()
            row.template_list(
                "RENDER_UL_presets", "", 
                scene, "render_presets",
                scene, "active_preset_index", 
                rows=3
            )
            
            # Preset management buttons
            col = row.column(align=True)
            col.operator("render.add_preset", icon='ADD', text="")
            col.operator("render.remove_preset", icon='REMOVE', text="")
            col.separator()
            col.operator("render.move_preset", icon='TRIA_UP', text="").direction = 'UP'
            col.operator("render.move_preset", icon='TRIA_DOWN', text="").direction = 'DOWN'
            
            # Apply preset button
            row = box.row()
            row.scale_y = 1.2
            row.operator("render.apply_preset", icon='CHECKMARK')
            
        except Exception as e:
            layout.label(text=f"Error: {str(e)}", icon='ERROR')

    def draw_render_actions(self, layout):
        box = layout.box()
        box.label(text="Quick Actions", icon='RENDER_STILL')
        
        # Main render buttons
        row = box.row(align=True)
        row.scale_y = 1.5
        row.operator("render.render", text="Render", icon='RENDER_STILL').use_viewport = True
        row.operator("render.render", text="Animation", icon='RENDER_ANIMATION').animation = True
        

    def draw_resolution_settings(self, layout, render, prefs):
        box = layout.box()
        box.label(text="Resolution", icon='IMAGE')
        
        # Resolution inputs in grid
        grid = box.grid_flow(row_major=True, columns=2, align=True)
        grid.prop(render, "resolution_x", text="Width")
        grid.prop(render, "resolution_y", text="Height")
        
        # Resolution tools
        row = box.row(align=True)
        row.operator("render.swap_resolution", text="", icon='FILE_REFRESH')
        row.operator("render.reset_resolution", text="Reset", icon='LOOP_BACK')

        # Resolution scale presets
        flow = box.grid_flow(row_major=True, columns=3, align=True)
        for scale in RESOLUTION_SCALES:
            flow.operator("render.set_resolution", 
                         text=f"{scale}%",
                         depress=(render.resolution_percentage == scale)
                        ).scale = scale

    def draw_frame_range(self, layout, scene):
        box = layout.box()
        box.label(text="Frame Range", icon='TIME')
        
        # Modern split layout for frame range
        split = box.split(factor=0.5)
        col = split.column(align=True)
        col.label(text="Start:")
        col.label(text="End:")
        
        col = split.column(align=True)
        col.prop(scene, "frame_start", text="")
        col.prop(scene, "frame_end", text="")

    def draw_sampling_settings(self, layout, context):
        box = layout.box()
        box.label(text="Quick Sampling", icon='MODIFIER')
        
        # Modern grid layout for sample presets
        flow = box.grid_flow(row_major=True, columns=3, align=True)
        for preset_name, samples in SAMPLE_PRESETS.items():
            # Highlight active preset
            is_active = False
            if context.scene.render.engine == 'CYCLES':
                is_active = (context.scene.cycles.samples == samples)
            
            flow.operator("render.set_samples", 
                         text=preset_name,
                         depress=is_active
                        ).samples = samples
        
        if context.scene.render.engine == 'CYCLES':
            box.label(text=f"Current: {context.scene.cycles.samples} samples", 
                     icon='INFO')
        else:
            box.label(text="Switch to Cycles to adjust samples", 
                     icon='ERROR')

    def draw_output_settings(self, layout, prefs):
        box = layout.box()
        box.label(text="Output Settings", icon='FILE_FOLDER')
        
        # Modern file path layout
        row = box.row(align=True)
        row.prop(prefs, "default_output_path", text="")
        row.operator("render.open_folder", text="", icon='FILE_FOLDER')
        
        # Settings grid
        grid = box.grid_flow(row_major=True, columns=2, align=True)
        grid.prop(prefs, "save_on_render")
        grid.prop(prefs, "show_render_time")
        grid.prop(prefs, "use_subfolders")
        
        # Save actions
        row = box.row(align=True)
        row.operator("render.save_render", icon='FILE_TICK')
        row.operator("render.open_folder", icon='FILEBROWSER')
    

    def draw_presets(self, layout):
        box = layout.box()
        box.label(text="Presets", icon='PRESET')
        
        # Modern preset management
        row = box.row(align=True)
        row.operator("render.save_preset", icon='FILE_TICK')
        row.operator("render.load_preset", icon='PRESET')
        
        # Display current preset if any
        if hasattr(bpy.context.scene, "render_preset"):
            box.label(text=f"Active: {bpy.context.scene.render_preset}", 
                     icon='CHECKMARK')

class RENDER_PT_batch_cameras(bpy.types.Panel):
    bl_label = "Batch Camera Render"
    bl_idname = "RENDER_PT_batch_cameras"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "render"  # Changed from "render_it" to "render"
    bl_parent_id = "RENDER_PT_zone"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
    
        # Camera list with modern UI
        row = layout.row()
        row.template_list("RENDER_UL_cameras", "", scene, "camera_list",
                         scene, "active_camera_index", rows=3)
    
        # List management buttons
        col = row.column(align=True)
        col.operator("render.add_batch_camera", icon='ADD', text="")
        col.operator("render.remove_batch_camera", icon='REMOVE', text="")
        col.separator()
        col.operator("render.move_batch_camera", icon='TRIA_UP', text="").direction = 'UP'
        col.operator("render.move_batch_camera", icon='TRIA_DOWN', text="").direction = 'DOWN'
    
        # Selected camera settings
        if len(scene.camera_list) > 0 and scene.active_camera_index >= 0:
            self.draw_camera_settings(context, layout)
    
        # Batch render and cancel buttons
        row = layout.row(align=True)
        row.scale_y = 1.5
        row.operator("render.batch_render_cameras", icon='RENDER_ANIMATION')
        

    def draw_camera_settings(self, context, layout):
        cam_settings = context.scene.camera_list[context.scene.active_camera_index]
        
        # Camera selection and options
        box = layout.box()
        row = box.row()
        row.prop(cam_settings, "camera")
        row.prop(cam_settings, "enabled", text="")
        
        # Frame range settings
        box.prop(cam_settings, "use_scene_frames")
        if not cam_settings.use_scene_frames:
            grid = box.grid_flow(row_major=True, columns=2, align=True)
            grid.prop(cam_settings, "frame_start")
            grid.prop(cam_settings, "frame_end")
        
        # Output settings
        box = layout.box()
        box.label(text="Output Settings", icon='FILE_FOLDER')
        
        box.prop(cam_settings, "use_custom_folder")
        if cam_settings.use_custom_folder:
            row = box.row(align=True)
            row.prop(cam_settings, "output_folder", text="")
            row.operator("render.open_folder", text="", icon='FILE_FOLDER')
        
        box.prop(cam_settings, "create_subfolder")
        if cam_settings.create_subfolder:
            box.prop(cam_settings, "subfolder_name")
        
        box.prop(cam_settings, "register_render")

class RENDER_UL_cameras(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            
            # Camera name/selection
            if item.camera:
                row.prop(item.camera, "name", text="", emboss=False, icon='CAMERA_DATA')
            else:
                row.label(text="No Camera Selected", icon='ERROR')
            
            # Quick enable/disable toggle
            row.prop(item, "enabled", text="", icon='CHECKBOX_HLT' if item.enabled else 'CHECKBOX_DEHLT')
            
            # Frame range indicator
            if not item.use_scene_frames:
                row.label(text=f"{item.frame_start}-{item.frame_end}", icon='TIME')

class RENDER_OT_add_batch_camera(bpy.types.Operator):
    bl_idname = "render.add_batch_camera"
    bl_label = "Add Camera"
    bl_description = "Add a new camera to the batch render list"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        camera_list = context.scene.camera_list
        new_cam = camera_list.add()
        
        # Try to set active camera if available
        if context.scene.camera:
            new_cam.camera = context.scene.camera
            
        context.scene.active_camera_index = len(camera_list) - 1
        return {'FINISHED'}

class RENDER_OT_remove_batch_camera(bpy.types.Operator):
    bl_idname = "render.remove_batch_camera"
    bl_label = "Remove Camera"
    bl_description = "Remove selected camera from the batch render list"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.scene.camera_list

    def execute(self, context):
        camera_list = context.scene.camera_list
        index = context.scene.active_camera_index

        camera_list.remove(index)
        context.scene.active_camera_index = min(max(0, index - 1), len(camera_list) - 1)
        return {'FINISHED'}

class RENDER_OT_move_batch_camera(bpy.types.Operator):
    bl_idname = "render.move_batch_camera"
    bl_label = "Move Camera"
    bl_description = "Move camera in the list"
    bl_options = {'REGISTER', 'UNDO'}

    direction: bpy.props.EnumProperty(
        items=[
            ('UP', "Up", "Move camera up"),
            ('DOWN', "Down", "Move camera down"),
        ]
    )

    @classmethod
    def poll(cls, context):
        return context.scene.camera_list

    def execute(self, context):
        camera_list = context.scene.camera_list
        index = context.scene.active_camera_index

        if self.direction == 'UP' and index > 0:
            camera_list.move(index, index - 1)
            context.scene.active_camera_index -= 1
        elif self.direction == 'DOWN' and index < len(camera_list) - 1:
            camera_list.move(index, index + 1)
            context.scene.active_camera_index += 1

        return {'FINISHED'}

class RENDER_OT_batch_render_cameras(bpy.types.Operator):
    bl_idname = "render.batch_render_cameras"
    bl_label = "Batch Render Cameras"
    bl_description = "Render from all enabled cameras in the list"

    _timer = None
    is_rendering: bpy.props.BoolProperty(default=False)
    current_camera_index: bpy.props.IntProperty(default=0)
    total_frames: bpy.props.IntProperty(default=0)
    render_start_time: bpy.props.FloatProperty(default=0.0)

    @classmethod
    def poll(cls, context):
        # Simply check if there are cameras in the list
        return len(context.scene.camera_list) > 0

    def get_output_path(self, context, cam_settings):
        """Get the correct output path based on settings"""
        scene = context.scene
        prefs = get_prefs(context)
        
        # Start with base path
        if cam_settings.use_custom_folder and cam_settings.output_folder:
            # Use custom folder if specified
            base_path = bpy.path.abspath(cam_settings.output_folder)
        else:
            # Use default path from preferences
            base_path = bpy.path.abspath(prefs.default_output_path)
            
            # Add project name if set
            if prefs.project_name:
                base_path = os.path.join(base_path, prefs.project_name)
        
        # Add cameras folder
        base_path = os.path.join(base_path, "cameras")
        
        # Add camera-specific subfolder if enabled
        if cam_settings.create_subfolder:
            subfolder_name = (cam_settings.subfolder_name 
                            if cam_settings.subfolder_name 
                            else cam_settings.camera.name)
            base_path = os.path.join(base_path, subfolder_name)
            
        # Create directories
        os.makedirs(base_path, exist_ok=True)
        
        # Return full path including filename pattern
        return os.path.join(base_path, f"{cam_settings.camera.name}_####")
    
    def modal(self, context, event):
        if event.type == 'ESC':
            self.cancel(context)
            return {'CANCELLED'}
            
        if event.type == 'TIMER':
            if not self.is_rendering:
                if self.current_camera_index < len(context.scene.camera_list):
                    self.render_next_camera(context)
                else:
                    # All cameras done
                    self.cleanup(context)
                    self.report({'INFO'}, "Batch render completed!")
                    return {'FINISHED'}
                    
        return {'PASS_THROUGH'}
        
    def execute(self, context):
        scene = context.scene
        prefs = get_prefs(context)
        
        if not prefs:
            self.report({'ERROR'}, "Addon preferences not found!")
            return {'CANCELLED'}
            
        if not prefs.default_output_path:
            self.report({'ERROR'}, "Please set output path in addon preferences!")
            return {'CANCELLED'}

        # Check if already rendering
        if self.is_rendering:
            self.report({'WARNING'}, "Already rendering!")
            return {'CANCELLED'}
        
        if not prefs:
            self.report({'ERROR'}, "Addon preferences not found!")
            return {'CANCELLED'}
            
        if not prefs.default_output_path:
            self.report({'ERROR'}, "Please set output path in addon preferences!")
            return {'CANCELLED'}

        # Store original render settings
        self.original_camera = scene.camera
        self.original_state = self.save_render_state(scene)
        self.current_camera_index = 0
        self.is_rendering = False
        self.render_start_time = time.time()
        
        # Calculate total frames
        self.total_frames = 0
        for cam_settings in scene.camera_list:
            if cam_settings.enabled and cam_settings.camera:
                if cam_settings.use_scene_frames:
                    self.total_frames += (scene.frame_end - scene.frame_start + 1)
                else:
                    self.total_frames += (cam_settings.frame_end - cam_settings.frame_start + 1)
        
        # Add timer for modal
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.5, window=context.window)
        wm.modal_handler_add(self)
        
        self.report({'INFO'}, f"Starting batch render of {len(scene.camera_list)} cameras...")
        return {'RUNNING_MODAL'}
    
    def render_next_camera(self, context):
        scene = context.scene
        prefs = get_prefs(context)
        cam_settings = scene.camera_list[self.current_camera_index]
        
        if not cam_settings.enabled or not cam_settings.camera:
            self.current_camera_index += 1
            return
            
        # Set active camera
        scene.camera = cam_settings.camera
        
        # Setup output path
        if cam_settings.use_custom_folder and cam_settings.output_folder:
            base_path = bpy.path.abspath(cam_settings.output_folder)
        else:
            base_path = bpy.path.abspath(prefs.default_output_path)
        
        # Create project-specific path
        if prefs.project_name:
            path_parts = [base_path, prefs.project_name, "cameras"]
        else:
            path_parts = [base_path, "cameras"]
            
        # Add camera subfolder
        if cam_settings.create_subfolder:
            subfolder_name = (cam_settings.subfolder_name 
                            if cam_settings.subfolder_name 
                            else cam_settings.camera.name)
            path_parts.append(subfolder_name)
        
        output_path = os.path.join(*path_parts)
        
        # Ensure directory exists
        try:
            os.makedirs(output_path, exist_ok=True)
        except Exception as e:
            self.report({'ERROR'}, f"Failed to create directory: {str(e)}")
            self.current_camera_index += 1
            return
        
        # Setup render settings
        scene.render.image_settings.file_format = 'PNG'
        scene.render.use_file_extension = True
        scene.render.use_placeholder = True
        scene.render.use_overwrite = True
        
        # Set frame range
        if not cam_settings.use_scene_frames:
            scene.frame_start = cam_settings.frame_start
            scene.frame_end = cam_settings.frame_end
        
        # Set output path with frame placeholder
        scene.render.filepath = os.path.join(
            output_path,
            f"{cam_settings.camera.name}_####"
        )
        
        # Register handlers
        bpy.app.handlers.render_complete.append(self.render_complete)
        bpy.app.handlers.render_cancel.append(self.render_cancel)
        
        # Start render
        self.is_rendering = True
        elapsed_time = time.time() - self.render_start_time
        frames_done = self.get_completed_frames()
        
        if frames_done > 0:
            avg_time_per_frame = elapsed_time / frames_done
            frames_remaining = self.total_frames - frames_done
            estimated_time = frames_remaining * avg_time_per_frame
            self.report({'INFO'}, 
                       f"Rendering camera {self.current_camera_index + 1}/{len(scene.camera_list)} - "
                       f"Estimated time remaining: {self.format_time(estimated_time)}")
        else:
            self.report({'INFO'}, 
                       f"Rendering camera {self.current_camera_index + 1}/{len(scene.camera_list)}")
            
        bpy.ops.render.render('INVOKE_DEFAULT', animation=True)
    
    def render_complete(self, scene, *args):
        self.cleanup_render_handlers()
        self.is_rendering = False
        self.current_camera_index += 1
    
    def render_cancel(self, scene, *args):
        self.cleanup_render_handlers()
        self.is_rendering = False
        self.current_camera_index += 1
    
    def cleanup_render_handlers(self):
        if self.render_complete in bpy.app.handlers.render_complete:
            bpy.app.handlers.render_complete.remove(self.render_complete)
        if self.render_cancel in bpy.app.handlers.render_cancel:
            bpy.app.handlers.render_cancel.remove(self.render_cancel)
    
    def cleanup(self, context):
        try:
            # Remove timer
            if self._timer:
                context.window_manager.event_timer_remove(self._timer)
            
            # Restore original settings
            if hasattr(self, 'original_camera'):
                context.scene.camera = self.original_camera
            if hasattr(self, 'original_state'):
                self.restore_render_state(context.scene, self.original_state)
                
            # Final report
            elapsed_time = time.time() - self.render_start_time
            self.report({'INFO'}, 
                       f"Batch render completed in {self.format_time(elapsed_time)}")
        except Exception as e:
            self.report({'ERROR'}, f"Error during cleanup: {str(e)}")
        
    def cancel(self, context):
        if self.is_rendering:
            bpy.ops.render.cancel()
        self.cleanup(context)
        self.report({'INFO'}, "Batch render cancelled!")

    def save_render_state(self, scene):
        return {
            'original_path': scene.render.filepath,
            'original_format': scene.render.image_settings.file_format,
            'original_use_file_extension': scene.render.use_file_extension,
            'original_use_placeholder': scene.render.use_placeholder,
            'original_use_overwrite': scene.render.use_overwrite,
            'original_frame_start': scene.frame_start,
            'original_frame_end': scene.frame_end
        }

    def restore_render_state(self, scene, state):
        scene.render.filepath = state['original_path']
        scene.render.image_settings.file_format = state['original_format']
        scene.render.use_file_extension = state['original_use_file_extension']
        scene.render.use_placeholder = state['original_use_placeholder']
        scene.render.use_overwrite = state['original_use_overwrite']
        scene.frame_start = state['original_frame_start']
        scene.frame_end = state['original_frame_end']

    def get_completed_frames(self):
        completed = 0
        for i in range(self.current_camera_index):
            cam_settings = bpy.context.scene.camera_list[i]
            if cam_settings.enabled and cam_settings.camera:
                if cam_settings.use_scene_frames:
                    completed += (bpy.context.scene.frame_end - bpy.context.scene.frame_start + 1)
                else:
                    completed += (cam_settings.frame_end - cam_settings.frame_start + 1)
        return completed

    def format_time(self, seconds):
        """Format time in seconds to human readable string"""
        minutes, seconds = divmod(int(seconds), 60)
        hours, minutes = divmod(minutes, 60)
        
        if hours > 0:
            return f"{hours}h {minutes}m {seconds}s"
        elif minutes > 0:
            return f"{minutes}m {seconds}s"
        else:
            return f"{seconds}s"


class RENDER_UL_presets(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.label(text=item.name, icon='PRESET')
            row.prop(item, "is_selected", text="", icon='CHECKBOX_HLT' if item.is_selected else 'CHECKBOX_DEHLT')

class PresetSettings(PropertyGroup):
    name: StringProperty(name="Name")
    is_selected: BoolProperty(name="Selected", default=False)
    resolution_x: IntProperty(name="Width")
    resolution_y: IntProperty(name="Height")
    resolution_percentage: IntProperty(name="Scale")
    engine: StringProperty(name="Engine")
    cycles_samples: IntProperty(name="Samples")

def draw_presets(self, layout):
    box = layout.box()
    box.label(text="Render Presets", icon='PRESET')

    # Preset list with management buttons
    row = box.row()
    
    # Template list
    row.template_list(
        "RENDER_UL_presets", "", 
        bpy.context.scene, "render_presets",
        bpy.context.scene, "active_preset_index", 
        rows=3
    )
    
    # List management buttons
    col = row.column(align=True)
    col.operator("render.add_preset", icon='ADD', text="")
    col.operator("render.remove_preset", icon='REMOVE', text="")
    col.separator()
    col.operator("render.move_preset", icon='TRIA_UP', text="").direction = 'UP'
    col.operator("render.move_preset", icon='TRIA_DOWN', text="").direction = 'DOWN'
    
    # Apply button
    row = box.row()
    row.scale_y = 1.2
    row.operator("render.apply_preset", icon='CHECKMARK')

class RENDER_OT_add_preset(bpy.types.Operator):
    bl_idname = "render.add_preset"
    bl_label = "Add Preset"
    bl_description = "Add a new render preset"
    bl_options = {'REGISTER', 'UNDO'}

    preset_name: StringProperty(
        name="Preset Name",
        description="Name for the new preset",
        default="New Preset"
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "preset_name")

    def execute(self, context):
        scene = context.scene
        render = scene.render
        cycles = scene.cycles

        preset = scene.render_presets.add()
        preset.name = self.preset_name
        preset.resolution_x = render.resolution_x
        preset.resolution_y = render.resolution_y
        preset.resolution_percentage = render.resolution_percentage
        preset.engine = render.engine
        if render.engine == 'CYCLES':
            preset.cycles_samples = cycles.samples

        scene.active_preset_index = len(scene.render_presets) - 1
        return {'FINISHED'}

class RENDER_OT_remove_preset(bpy.types.Operator):
    bl_idname = "render.remove_preset"
    bl_label = "Remove Preset"
    bl_description = "Remove selected preset"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.scene.render_presets

    def execute(self, context):
        scene = context.scene
        presets = scene.render_presets
        index = scene.active_preset_index

        presets.remove(index)
        scene.active_preset_index = min(max(0, index - 1), len(presets) - 1)
        return {'FINISHED'}

class RENDER_OT_move_preset(bpy.types.Operator):
    bl_idname = "render.move_preset"
    bl_label = "Move Preset"
    bl_description = "Move preset in list"
    bl_options = {'REGISTER', 'UNDO'}

    direction: EnumProperty(
        items=[
            ('UP', "Up", "Move preset up"),
            ('DOWN', "Down", "Move preset down"),
        ]
    )

    @classmethod
    def poll(cls, context):
        return context.scene.render_presets

    def execute(self, context):
        scene = context.scene
        presets = scene.render_presets
        index = scene.active_preset_index

        if self.direction == 'UP' and index > 0:
            presets.move(index, index - 1)
            scene.active_preset_index -= 1
        elif self.direction == 'DOWN' and index < len(presets) - 1:
            presets.move(index, index + 1)
            scene.active_preset_index += 1

        return {'FINISHED'}

class RENDER_OT_apply_preset(bpy.types.Operator):
    bl_idname = "render.apply_preset"
    bl_label = "Apply Preset"
    bl_description = "Apply selected preset"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.scene.render_presets and 
                context.scene.active_preset_index >= 0 and 
                context.scene.active_preset_index < len(context.scene.render_presets))

    def execute(self, context):
        scene = context.scene
        render = scene.render
        preset = scene.render_presets[scene.active_preset_index]

        render.resolution_x = preset.resolution_x
        render.resolution_y = preset.resolution_y
        render.resolution_percentage = preset.resolution_percentage
        render.engine = preset.engine
        
        if preset.engine == 'CYCLES':
            scene.cycles.samples = preset.cycles_samples

        self.report({'INFO'}, f"Applied preset: {preset.name}")
        return {'FINISHED'}

# Property Space Context Registration
class RENDER_HT_header(bpy.types.Header):
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'HEADER'

    def draw(self, context):
        layout = self.layout
        layout.context_pointer_set("render_it", context.scene)

def add_render_it_button(self, context):
    layout = self.layout
    layout.prop_enum(
        context.space_data,
        "context",
        "render_it",
        icon='RENDER_STILL',
        text="Render It"
    )

# Additional Utility Operators
class RENDER_OT_swap_resolution(bpy.types.Operator):
    bl_idname = "render.swap_resolution"
    bl_label = "Swap Resolution"
    bl_description = "Swap width and height values"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        render = context.scene.render
        render.resolution_x, render.resolution_y = render.resolution_y, render.resolution_x
        return {'FINISHED'}

class RENDER_OT_reset_resolution(bpy.types.Operator):
    bl_idname = "render.reset_resolution"
    bl_label = "Reset Resolution"
    bl_description = "Reset to default resolution"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        prefs = get_prefs(context)
        render = context.scene.render
        render.resolution_x = prefs.default_resolution_x
        render.resolution_y = prefs.default_resolution_y
        render.resolution_percentage = 100
        return {'FINISHED'}

class RENDER_OT_set_resolution(bpy.types.Operator):
    bl_idname = "render.set_resolution"
    bl_label = "Set Resolution Scale"
    bl_description = "Set resolution percentage"
    bl_options = {'REGISTER', 'UNDO'}

    scale: bpy.props.IntProperty(
        name="Scale",
        description="Resolution scale percentage",
        default=100,
        min=1,
        max=200
    )

    def execute(self, context):
        context.scene.render.resolution_percentage = self.scale
        return {'FINISHED'}

class RENDER_OT_set_samples(bpy.types.Operator):
    bl_idname = "render.set_samples"
    bl_label = "Set Samples"
    bl_description = "Set render samples"
    bl_options = {'REGISTER', 'UNDO'}

    samples: bpy.props.IntProperty(
        name="Samples",
        description="Number of render samples",
        default=128,
        min=1
    )

    @classmethod
    def poll(cls, context):
        return context.scene.render.engine == 'CYCLES'
    
    def execute(self, context):
        if context.scene.render.engine == 'CYCLES':
            context.scene.cycles.samples = self.samples
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Switch to Cycles render engine to set samples")
            return {'CANCELLED'}

class RENDER_OT_open_folder(bpy.types.Operator):
    bl_idname = "render.open_folder"
    bl_label = "Open Folder"
    bl_description = "Open the render output folder"
    bl_options = {'REGISTER'} 

    def execute(self, context):
        prefs = get_prefs(context)
        path = bpy.path.abspath(prefs.default_output_path)
        
        try:
            ensure_dir_exists(path)
            bpy.ops.wm.path_open(filepath=path)
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Could not open folder: {str(e)}")
            return {'CANCELLED'}

class RENDER_OT_save_render(bpy.types.Operator):
    bl_idname = "render.save_render"
    bl_label = "Save Render"
    bl_description = "Save the current render"
    bl_options = {'REGISTER'}

    def execute(self, context):
        if not bpy.data.images['Render Result']:
            self.report({'ERROR'}, "No render to save")
            return {'CANCELLED'}
            
        try:
            prefs = get_prefs(context)
            output_path = get_project_output_path(context, "renders")
            
            # Generate filename with timestamp
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filepath = os.path.join(output_path, f"render_{timestamp}.png")
            
            # Save render
            bpy.data.images['Render Result'].save_render(filepath=filepath)
            self.report({'INFO'}, f"Saved render to: {filepath}")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to save render: {str(e)}")
            return {'CANCELLED'}

class RENDER_OT_refresh_stats(Operator):
    bl_idname = "render.refresh_stats"
    bl_label = "Refresh Statistics"
    bl_description = "Refresh render statistics"

    def execute(self, context):
        for area in context.screen.areas:
            if area.type == 'PROPERTIES':
                area.tag_redraw()
        return {'FINISHED'}

class RENDER_PT_passes(bpy.types.Panel):
    bl_label = "Render Passes"
    bl_idname = "RENDER_PT_passes"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "render"
    bl_parent_id = "RENDER_PT_zone"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        rd = scene.render

        if rd.engine == 'CYCLES':
            view_layer = context.view_layer
            cycles_view_layer = view_layer.cycles

            # Data Passes
            box = layout.box()
            box.label(text="Data Passes", icon='NODE_MATERIAL')
            
            flow = box.grid_flow(row_major=True, columns=2, align=True)
            flow.prop(view_layer, "use_pass_combined")
            flow.prop(view_layer, "use_pass_z")
            flow.prop(view_layer, "use_pass_mist")
            flow.prop(view_layer, "use_pass_normal")
            flow.prop(view_layer, "use_pass_position")
            flow.prop(view_layer, "use_pass_vector")
            flow.prop(view_layer, "use_pass_uv")

            # Light Passes
            box = layout.box()
            box.label(text="Light Passes", icon='LIGHT')
            
            flow = box.grid_flow(row_major=True, columns=2, align=True)
            flow.prop(view_layer, "use_pass_diffuse_direct")
            flow.prop(view_layer, "use_pass_diffuse_indirect")
            flow.prop(view_layer, "use_pass_diffuse_color")
            flow.prop(view_layer, "use_pass_glossy_direct")
            flow.prop(view_layer, "use_pass_glossy_indirect")
            flow.prop(view_layer, "use_pass_glossy_color")
            flow.prop(view_layer, "use_pass_transmission_direct")
            flow.prop(view_layer, "use_pass_transmission_indirect")
            flow.prop(view_layer, "use_pass_transmission_color")
            flow.prop(view_layer, "use_pass_emit")
            flow.prop(view_layer, "use_pass_environment")
            flow.prop(view_layer, "use_pass_shadow")
            flow.prop(view_layer, "use_pass_ambient_occlusion")

            # Cryptomatte
            box = layout.box()
            box.label(text="Cryptomatte", icon='OUTLINER_DATA_VOLUME')
            
            flow = box.grid_flow(row_major=True, columns=2, align=True)
            flow.prop(view_layer, "use_pass_cryptomatte_object")
            flow.prop(view_layer, "use_pass_cryptomatte_material")
            flow.prop(view_layer, "use_pass_cryptomatte_asset")
            if any((view_layer.use_pass_cryptomatte_object,
                   view_layer.use_pass_cryptomatte_material,
                   view_layer.use_pass_cryptomatte_asset)):
                col = box.column(align=True)
                col.prop(cycles_view_layer, "pass_cryptomatte_depth")
                col.prop(cycles_view_layer, "use_pass_cryptomatte_accurate")

            # Add Node Setup Button
            box = layout.box()
            box.label(text="Node Setup", icon='NODETREE')
            row = box.row()
            row.operator("render.setup_render_passes_nodes", icon='NODE_COMPOSITING')

        elif rd.engine == 'BLENDER_EEVEE':
            view_layer = context.view_layer
            
            # Eevee Passes
            box = layout.box()
            box.label(text="Eevee Passes", icon='NODE_MATERIAL')


class RENDER_OT_setup_render_passes_nodes(bpy.types.Operator):
    bl_idname = "render.setup_render_passes_nodes"
    bl_label = "Setup Render Passes Nodes"
    bl_description = "Create node setup for enabled render passes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        view_layer = context.view_layer
        prefs = get_prefs(context)

        if not prefs:
            self.report({'ERROR'}, "Addon preferences not found!")
            return {'CANCELLED'}

        # Enable nodes and get tree
        scene.use_nodes = True
        tree = scene.node_tree

        # Clear existing nodes
        tree.nodes.clear()

        # Create render layers node
        rl_node = tree.nodes.new('CompositorNodeRLayers')
        rl_node.location = (0, 0)

        # Get base output path from preferences
        base_path = bpy.path.abspath(prefs.default_output_path)
        if prefs.project_name:
            base_path = os.path.join(base_path, prefs.project_name)
        
        # Create "passes" subfolder in output path
        passes_path = os.path.join(base_path, "passes")
        os.makedirs(passes_path, exist_ok=True)

        # Create viewer and composite nodes for combined pass
        viewer_node = tree.nodes.new('CompositorNodeViewer')
        viewer_node.location = (300, 200)
        composite_node = tree.nodes.new('CompositorNodeComposite')
        composite_node.location = (300, 0)

        # Link combined pass
        tree.links.new(rl_node.outputs['Image'], viewer_node.inputs[0])
        tree.links.new(rl_node.outputs['Image'], composite_node.inputs[0])

        # Dictionary of pass names and their nice names for filenames
        pass_names = {
            'Depth': 'depth',
            'Mist': 'mist',
            'Normal': 'normal',
            'Position': 'position',
            'Vector': 'vector',
            'UV': 'uv',
            'Diffuse Direct': 'diffuse_direct',
            'Diffuse Indirect': 'diffuse_indirect',
            'Diffuse Color': 'diffuse_color',
            'Glossy Direct': 'glossy_direct',
            'Glossy Indirect': 'glossy_indirect',
            'Glossy Color': 'glossy_color',
            'Transmission Direct': 'transmission_direct',
            'Transmission Indirect': 'transmission_indirect',
            'Transmission Color': 'transmission_color',
            'Emit': 'emission',
            'Environment': 'environment',
            'Shadow': 'shadow',
            'AO': 'ao',
            'Crypto Object': 'crypto_object',
            'Crypto Material': 'crypto_material',
            'Crypto Asset': 'crypto_asset'
        }

        # Setup nodes for each enabled pass
        x_offset = 300
        y_offset = -300

        for output in rl_node.outputs:
            if output.enabled and output.name in pass_names:
                # Create file output node
                file_node = tree.nodes.new('CompositorNodeOutputFile')
                file_node.location = (x_offset, y_offset)
                file_node.base_path = os.path.join(passes_path, pass_names[output.name])
                
                # Set format settings
                file_node.format.file_format = 'PNG'
                file_node.format.color_mode = 'RGBA'
                file_node.format.color_depth = '16'
                
                # Add input slot if needed
                if len(file_node.file_slots) == 0:
                    file_node.file_slots.new("####")
                else:
                    file_node.file_slots[0].path = "####"
                
                # Link pass to file output
                tree.links.new(output, file_node.inputs[0])
                
                y_offset -= 200

        # Create frame to group file output nodes
        frame = tree.nodes.new('NodeFrame')
        frame.label = "Pass Outputs"
        frame.label_size = 20
        
        # Add file output nodes to frame
        for node in tree.nodes:
            if node.type == 'OUTPUT_FILE':
                node.parent = frame

        self.report({'INFO'}, f"Render passes node setup complete. Outputs will be saved to: {passes_path}")
        return {'FINISHED'}

    def create_pass_output(self, tree, output, base_path, pass_name, location):
        """Helper function to create output node for a pass"""
        file_node = tree.nodes.new('CompositorNodeOutputFile')
        file_node.location = location
        file_node.base_path = os.path.join(base_path, pass_name)
        
        # Ensure at least one input slot exists
        if len(file_node.file_slots) == 0:
            file_node.file_slots.new("####")
        else:
            file_node.file_slots[0].path = "####"
            
        # Set format settings
        file_node.format.file_format = 'PNG'
        file_node.format.color_mode = 'RGBA'
        file_node.format.color_depth = '16'
        
        return file_node


# Registration
classes = (
    RenderItPreferences,
    CameraRenderSettings,
    RENDER_PT_zone,
    RENDER_PT_batch_cameras,
    RENDER_PT_passes,
    RENDER_UL_cameras,
    RENDER_UL_presets,
    PresetSettings,
    RENDER_OT_batch_render_cameras,
    RENDER_OT_add_batch_camera,
    RENDER_OT_remove_batch_camera,
    RENDER_OT_move_batch_camera,
    RENDER_OT_swap_resolution,
    RENDER_OT_reset_resolution,
    RENDER_OT_set_resolution,
    RENDER_OT_set_samples,
    RENDER_OT_open_folder,
    RENDER_OT_save_render,
    RENDER_OT_setup_render_passes_nodes,
    RENDER_OT_add_preset,
    RENDER_OT_remove_preset,
    RENDER_OT_move_preset,
    RENDER_OT_apply_preset,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    
    # Register properties
    bpy.types.Scene.camera_list = bpy.props.CollectionProperty(type=CameraRenderSettings)
    bpy.types.Scene.active_camera_index = bpy.props.IntProperty()
    bpy.types.Scene.render_presets = bpy.props.CollectionProperty(type=PresetSettings)
    bpy.types.Scene.active_preset_index = bpy.props.IntProperty()

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    
    # Unregister properties
    del bpy.types.Scene.camera_list
    del bpy.types.Scene.active_camera_index
    del bpy.types.Scene.render_presets
    del bpy.types.Scene.active_preset_index



if __name__ == "__main__":
    register()

